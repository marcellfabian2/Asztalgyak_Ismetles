﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace konyvkiadas
{
    internal class Kiadasok
    {
        public int ev {  get; set; }
        public int negyed { get; set; }
        public string eredet { get; set; }
        public string leiras { get; set; }
        public int peldanyszam { get; set; }

        public Kiadasok(string item)
        {
            string[] temp = item.Split(';');
            ev = int.Parse(temp[0]);
            negyed = int.Parse(temp[1]);
            eredet = temp[2];
            leiras = temp[3];
            peldanyszam = int.Parse(temp[4]);
        }

    }
}
