﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace konyvkiadas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Kiadasok> kiadasok = new List<Kiadasok>();
            foreach(var item in File.ReadAllLines("kiadas.txt"))
            {
                Kiadasok k = new Kiadasok(item);
                kiadasok.Add(k);
            }

            //2. feladat
            Console.Write("2. feladat:\nSzerző: ");

            string beker = Console.ReadLine();
            int db = 0;
            foreach(var item in kiadasok)
            {
                if(item.leiras.StartsWith(beker))
                {
                    db++;
                }
            }
            if(db == 0)
            {
                Console.WriteLine("Nem adtak ki");
            }
            else
            {
                Console.WriteLine($"{db} könyvkiadás");
            }

            //3. feladat
            int max = 0;
            int db1 = 0;
            foreach (var item in kiadasok)
            {
                if(item.peldanyszam > max)
                {
                    max = item.peldanyszam;
                }
            }
            foreach (var item in kiadasok)
            {
                if(max == item.peldanyszam)
                {
                    db1++;
                }
            }
            Console.WriteLine($"3. feladat:\r\nLegnagyobb példányszám: {max}, előfordult {db1} alkalommal");

            //4. feladat
            foreach (var item in kiadasok)
            {
                if (item.eredet == "kf" && item.peldanyszam >= 40000)
                {
                    Console.WriteLine($"4. feladat:\r\n{item.ev}/{item.negyed}. {item.leiras}");
                    break;
                }
            }
            
            //5.feladat
            List<int> evek = new List<int>();
            foreach(var item in kiadasok)
            {
                if (!evek.Contains(item.ev))
                {
                    evek.Add(item.ev);
                }       
            }
            Console.WriteLine("5. feladat:");
            Console.WriteLine("Év\tMagyar kiadás\t Magyar példányszám\t Külföldi kiadás\t Külföldi példányszám");
            foreach(var ev in evek)
            {
                int mkiadas = 0;
                int mpeldany = 0;
                int kkiadas = 0;
                int kpeldany = 0;
                foreach (var item in kiadasok)
                {
                    if(item.ev == ev)
                    {
                        if(item.eredet == "ma")
                        {
                            mkiadas++;
                            mpeldany += item.peldanyszam;
                        }
                        else
                        {
                            kkiadas++;
                            kpeldany += item.peldanyszam;
                        }
                    }
                }
                Console.WriteLine($"{ev}\t\t{mkiadas}\t\t{mpeldany}\t\t\t{kkiadas}\t\t\t{kpeldany}");
            }






            //6. feladat
            for (int i = 0; i < kiadasok.Count; i++)
            {
                int nagyobbak = 0;
                for (int j = i + 1; j < kiadasok.Count; j++)
                {
                    if (kiadasok[i].leiras == kiadasok[j].leiras &&
                        kiadasok[j].peldanyszam > kiadasok[i].peldanyszam)
                    {
                        nagyobbak++;
                    }
                }

                if (nagyobbak >= 2)
                {
                    Console.WriteLine(kiadasok[i].leiras);
                }
            }
            Console.ReadKey();
        }
    }
}
