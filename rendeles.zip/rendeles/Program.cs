﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace rendeles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Rendeles> rendelM = new List<Rendeles>();
            List<RendelesT> rendelT = new List<RendelesT>();

            StreamWriter sw = new StreamWriter("levelek.csv");

            foreach (var i in File.ReadAllLines("rendeles.csv"))
            {
                
                if (i.StartsWith("M"))
                {
                    Rendeles r1 = new Rendeles(i);
                    rendelM.Add(r1);
                }
                else if(i.StartsWith("T"))
                {
                    RendelesT r2 = new RendelesT(i);
                    rendelT.Add(r2);
                }

            }

            foreach(var i in rendelM)
            {
                foreach(var j in rendelT)
                {
                    if (i.rend_szama == j.RendelesSzam)
                    {
                        i.Tetelek.Add(j);
                    }
                }
                
            }


            List<Raktar> raktar = new List<Raktar>();
            foreach (var i in File.ReadAllLines("raktar.csv"))
            {
                Raktar rak = new Raktar(i);
                raktar.Add(rak);
            }

            //2-3. feladat

            foreach (var i in rendelM)
            {
                bool teljesitheto = true;

                foreach (var l in i.Tetelek)
                {
                    Raktar talalat = null;
                    foreach (var r in raktar)
                    {
                        if (r.termekkod == l.Cikkszam)
                        {
                            talalat = r;
                            break;
                        }
                    }

                    if (talalat == null || talalat.mennyiseg < l.Mennyiseg)
                    {
                        teljesitheto = false;
                        break;
                    }
                }

                if (teljesitheto)
                {
                    int osszeg = 0;

                    foreach (var l in i.Tetelek)
                    {
                        foreach (var r in raktar)
                        {
                            if (r.termekkod == l.Cikkszam)
                            {
                                r.mennyiseg -= l.Mennyiseg;
                                osszeg += l.Mennyiseg * r.ara;
                                break;
                            }
                        }
                    }

                    sw.WriteLine($"{i.email};A rendelését két napon belül szállítjuk. A rendelés értéke: {osszeg} Ft");
                }
                else
                {
                    sw.WriteLine($"{i.email};A rendelése függő állapotba került. Hamarosan értesítjük a szállítás időpontjáról.");
                }
            }

            //4. feladat
            Dictionary<string, int> beszerzes = new Dictionary<string, int>();

            foreach (var i in rendelM)
            {
                bool teljesitheto = true;

                foreach (var l in i.Tetelek)
                {
                    Raktar talalat = null;
                    foreach (var r in raktar)
                    {
                        if (r.termekkod == l.Cikkszam)
                        {
                            talalat = r;
                            break;
                        }
                    }

                    if (talalat == null || talalat.mennyiseg < l.Mennyiseg)
                    {
                        teljesitheto = false;
                        break;
                    }
                }

                if (!teljesitheto) 
                {
                    foreach (var l in i.Tetelek)
                    {
                        Raktar talalat = null;
                        foreach (var r in raktar)
                        {
                            if (r.termekkod == l.Cikkszam)
                            {
                                talalat = r;
                                break;
                            }
                        }

                        int hiany = 0;
                        if (talalat == null)
                        {
                            hiany = l.Mennyiseg; 
                        }
                        else if (talalat.mennyiseg < l.Mennyiseg)
                        {
                            hiany = l.Mennyiseg - talalat.mennyiseg;
                        }

                        if (hiany > 0)
                        {
                            if (!beszerzes.ContainsKey(l.Cikkszam))
                            {
                                beszerzes.Add(l.Cikkszam, hiany);
                            }
                            else
                            {
                                beszerzes[l.Cikkszam] += hiany;
                            }
                        }
                    }
                }
            }
            StreamWriter sw2 = new StreamWriter("beszerzes.csv");
            {
                foreach (var i in beszerzes)
                {
                    sw2.WriteLine($"{i.Key};{i.Value}");
                }
            }

            sw.Close();
            sw2.Close();
            Console.ReadKey();
        }
    }
}
