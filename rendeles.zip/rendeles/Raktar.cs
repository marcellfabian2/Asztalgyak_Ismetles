﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rendeles
{
    internal class Raktar
    {
        public string termekkod { get; set; }

        public string nev { get; set; }

        public int ara { get; set; }

        public int mennyiseg { get; set; }

        public Raktar(string item)
        {
            string[] temp = item.Split(';');
            termekkod = temp[0];
            nev = temp[1];
            ara = int.Parse(temp[2]);
            mennyiseg = int.Parse(temp[3]);

        }
    }


}