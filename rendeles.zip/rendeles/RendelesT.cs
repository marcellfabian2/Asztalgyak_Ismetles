﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rendeles
{
    internal class RendelesT
    {
        public string Sorszam { get; set; }
        public int RendelesSzam { get; set; }
        public string Cikkszam { get; set; }
        public int Mennyiseg { get; set; }

        public RendelesT(string item)
        {
            string[] tmp = item.Split(';');
            Sorszam = tmp[0];
            RendelesSzam = int.Parse(tmp[1]);
            Cikkszam = tmp[2];
            Mennyiseg = int.Parse(tmp[3]);
        }
    }
}
