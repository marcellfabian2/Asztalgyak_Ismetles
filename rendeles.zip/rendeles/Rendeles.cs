﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rendeles
{
    internal class Rendeles
    {
        public string t_jelolo { get; set; }

        public string rend_datum { get; set; }

        public int rend_szama { get; set; }

        public string email { get; set; }
        public List<RendelesT> Tetelek { get; set; } = new List<RendelesT>();
        public Rendeles(string item)
        {
            string[] temp = item.Split(';');
            t_jelolo = temp[0];
            rend_datum = temp[1];
            rend_szama = int.Parse(temp[2]);
            email = temp[3];
        }
    }
}
