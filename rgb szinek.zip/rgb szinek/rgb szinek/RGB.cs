﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rgb_szinek
{
    internal class RGB
    {
        public int R {  get; set; }
        public int G { get; set; }
        public int B { get; set; }
        public RGB(string item)
        {
            string[] tmp = item.Split();
            R = Convert.ToInt32(tmp[0]);
            G = Convert.ToInt32(tmp[1]);
            B = Convert.ToInt32(tmp[2]);


            
        }
    }
}
