﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace rgb
{
    internal class Program
    {
        static bool hatar(int sor, int elteres, Szinek[,] kep)
        {
            for (int j = 1; j < 640; j++)
            {
                if (Math.Abs(kep[sor, j].B - kep[sor, j - 1].B) > elteres)
                    return true;
            }
            return false;
        }
        static int Teteje(int elteres, Szinek[,] kep)
        {
            for (int sor = 0; sor < 360; sor++)
            {
                if (hatar(sor, elteres, kep))
                    return sor;
            }
            return -1;
        }
        static int Alja(int elteres, Szinek[,] kep)
        {
            for (int sor = 359; sor >= 0; sor--)
            {
                if (hatar(sor, elteres, kep))
                    return sor;
            }
            return -1;
        }
        static void Main(string[] args)
        {
            Szinek[,] kep = new Szinek[360, 640];

            StreamReader sr = new StreamReader("kep.txt");
            for (int sor = 0; sor < 360; sor++)
            {
                string[] s = sr.ReadLine().Split(' ');
                for (int oszlop = 0; oszlop < 640; oszlop++)
                {
                    kep[sor, oszlop] = new Szinek(s[oszlop * 3], s[oszlop * 3 + 1], s[oszlop * 3 + 2]);
                }
            }
            sr.Close();

            //2. feladat
            Console.WriteLine("2. feladat:");
            Console.WriteLine("Kérem egy képpont adatait!");
            Console.Write("Sor:");
            int row = int.Parse(Console.ReadLine());
            Console.Write("Oszlop:");
            int col = int.Parse(Console.ReadLine());
            Console.WriteLine($"A képpont színe RGB({kep[row - 1, col - 1].R} {kep[row - 1, col - 1].G} {kep[row - 1, col - 1].B})");

            //3. feladat
            int db = 0;
            for(int i = 0; i < 360; i++)
            {
                for(int j = 0; j < 640; j++)
                {
                    if (kep[i,j].Osszeg > 600)
                    {
                        db++;
                    }
                }
            }

            Console.WriteLine("3. feladat:");
            Console.WriteLine($"A világos képpontok száma: {db}");

            //4. feladat
            Console.WriteLine("4. feladat:");
            int legsotetebb = 1000000;

            for (int i = 0; i < 360; i++)
            {
                for (int j = 0; j < 640; j++)
                {
                    if (kep[i, j].Osszeg < legsotetebb)
                    {
                        legsotetebb = kep[i,j].Osszeg;
                    }
                }
            }
            Console.WriteLine($"A legsötétebb pont RGB összege: {legsotetebb}");
            Console.WriteLine("A legsötétebb pixelek színe:");
            for (int i = 0; i < 360; i++)
            {
                for (int j = 0; j < 640; j++)
                {
                    if (kep[i, j].Osszeg == legsotetebb)
                    {
                        Console.WriteLine($"RGB({kep[i, j].R},{kep[i, j].G},{kep[i,j].B})");
                    }
                }
            }

            Console.WriteLine("6. feladat:");
            Console.WriteLine($"A felhő legfelső sora: {Teteje(10, kep) + 1}");
            Console.WriteLine($"A felhő legalsó sora: {Alja(10, kep) + 1}");

            Console.ReadKey();
        }
    }
}
