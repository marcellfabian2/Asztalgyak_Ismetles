﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rgb
{
    internal class Szinek
    {
        public int R { get; set; }
        public int G { get; set; }
        public int B { get; set; }
        public int Osszeg { get; set; }

        public Szinek(string piros, string zold, string kek)
        {
            R = int.Parse(piros);
            G = int.Parse(zold);
            B = int.Parse(kek);
            Osszeg = R + G + B;
        }       
    }
}
