﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace letra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Dobas> dobasok = new List<Dobas>();

            foreach (var sor in File.ReadAllLines("dobasok.txt"))
            {
                foreach (var szam in sor.Split(','))
                {
                    Dobas d = new Dobas(int.Parse(szam));
                    dobasok.Add(d);
                }
            }


            //2. feladat
            int mezo = 0;
            int count = 0;

            List<int> lepesek = new List<int>();

            foreach(var i in dobasok)
            {
                mezo += i.Ertek;
                if(mezo % 10 == 0)
                {
                    mezo -= 3;
                    count++;
                }
                lepesek.Add(mezo);
                
            }

            //2. feladat
            Console.WriteLine("2. feladat");
            foreach(var i in lepesek)
            {
                Console.Write(i + " ");
            }

            //3. feladat
            Console.WriteLine($"\n3. feladat\nA játék során {count} alkalommal lépett létrára.");

            //4. feladat
            Console.WriteLine("4. feladat");
            if (lepesek[lepesek.Count - 1] >= 45)
            {
                Console.WriteLine("A játékot befejezte.");
            }
            else
            {
                Console.WriteLine("A játékot abbahagyta.");
            }

            Console.ReadKey();
        }
    }
}
