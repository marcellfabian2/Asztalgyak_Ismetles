﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Letra
{
    internal class Program
    {
        static void Main(string[] args)
        {
                int[] dobasok = { 3, 1, 1, 2, 1, 5, 5, 4, 4, 4, 1, 2, 3, 6, 4, 6, 1, 4 };
                Console.WriteLine("2. feladat");
                int tart = 0;
                int le = 0;
                for (int i = 0; i < dobasok.Count(); i++)
                {
                    tart += dobasok[i];
                    if (tart % 10 == 0)
                    {
                        tart -= 3;
                        le++;
                    }
                    Console.Write("{0} ", tart);
                }
                Console.WriteLine();
                Console.WriteLine("3. feladat");
                Console.WriteLine("A játék során {0} alkalommal lépett létrára.", le);

                Console.WriteLine("4. feladat");
                if (tart >= 45)
                {
                    Console.WriteLine("A játékot befejezte.");
                }
                else if (tart < 45)
                {
                    Console.WriteLine("A játékot abbahagyta.");
                }

            Console.ReadKey();
        }
    }
}
