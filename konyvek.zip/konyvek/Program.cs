﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

namespace konyvek
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Konyv> konyvek = new List<Konyv>();
            StreamWriter sw = new StreamWriter("tabla.html");

            foreach(var i in File.ReadLines("kiadas.txt"))
            {
                Konyv k = new Konyv(i);
                konyvek.Add(k);
            }

            //2. feladat
            Console.WriteLine("2. feladat:");
            Console.Write("Szerző: ");
            string nev = Console.ReadLine();

            int count = 0;
            bool van = false;

            foreach(var i in konyvek)
            {
                if (i.Leiras.Contains(nev))
                {
                    count++;
                    van = true;
                }
            }

            if (van)
            {
                Console.WriteLine($"{count} könyvkiadás");
            }
            else
            {
                Console.WriteLine("Nem adtak ki");
            }


            //3. feladat
            Konyv legnagyobb = konyvek[0];
            int c1 = 0;
            int c2 = 0;

            foreach(var i in konyvek)
            {
                if(i.Pedldanyszam > legnagyobb.Pedldanyszam)
                {
                    legnagyobb = i;
                    c1 = i.Pedldanyszam;
                }
            }

            foreach(var i in konyvek)
            {
                if(i.Pedldanyszam == c1)
                {
                    c2++;
                }
            }

            Console.WriteLine($"3. feladat:\nLegnagyobb példányszám: {legnagyobb.Pedldanyszam}, előfordult {c2} alkalommal");

            //4. feladat
            Console.WriteLine("4. feladat:");
            Konyv kulfoldi = konyvek[0];

            foreach(var i in konyvek)
            {
                if(i.Eredet == "kf" && i.Pedldanyszam > 40000)
                {
                    kulfoldi = i;
                    break;
                }
            }

            Console.WriteLine($"{kulfoldi.Ev}/{kulfoldi.Negyedev}. {kulfoldi.Leiras}");

            //5. feladat
            Console.WriteLine("5. feladat:");
            List<int> evek = new List<int>();

            foreach(var i in konyvek)
            {
                if (!evek.Contains(i.Ev))
                {
                    evek.Add(i.Ev);
                }
            }

            Console.WriteLine("Év\tMagyar kiadás\tMagyar példányszám\tKülföldi kiadás\tKülföldi példányszám");
            sw.WriteLine("<table>");
            sw.WriteLine("<tr><th>Év</th><th>Magyar kiadás</th><th>Magyar példányszám</th><th>Külföldi kiadás</th><th>Külföldi példányszám</th></tr>");
            int m = 0;
            int mp = 0; 
            int ku = 0;
            int kup = 0;
            foreach (var i in evek)
            {
                m = 0;
                mp = 0;
                ku = 0;
                kup = 0;
                foreach(var j in konyvek)
                {
                    if(j.Ev == i)
                    {
                        if(j.Eredet == "ma")
                        {
                            m++;
                            mp += j.Pedldanyszam;
                        }
                        if (j.Eredet == "kf")
                        {
                            ku++;
                            kup += j.Pedldanyszam;
                        }
                    }
                }
                Console.WriteLine($"{i}\t\t{m}\t\t{mp}\t\t{ku}\t\t{kup}");
                sw.WriteLine($"<tr><td>{i}</td><td>{m}</td><td>{mp}</td><td>{ku}</td><td>{kup}</td></tr>");
            }

            //6. feladat
            Console.WriteLine("6. feladat:");
            Console.WriteLine("Legalább kétszer, nagyobb példányszámban újra kiadott könyvek:");

            List<string> leirasok = new List<string>();

            foreach (var i in konyvek)
            {
                if (!leirasok.Contains(i.Leiras))
                {
                    leirasok.Add(i.Leiras);

                    Konyv elso = null;
                    foreach (var j in konyvek)
                    {
                        if (j.Leiras == i.Leiras)
                        {
                            if (elso == null || j.Ev < elso.Ev || (j.Ev == elso.Ev && j.Negyedev < elso.Negyedev))
                            {
                                elso = j;
                            }
                        }
                    }

                    int db = 0;
                    foreach (var j in konyvek)
                    {
                        if (j.Leiras == i.Leiras)
                        {
                            if ((j.Ev > elso.Ev || (j.Ev == elso.Ev && j.Negyedev > elso.Negyedev)) && j.Pedldanyszam > elso.Pedldanyszam)
                            {
                                db++;
                            }
                        }
                    }

                    if (db >= 2)
                    {
                        Console.WriteLine(i.Leiras);
                    }
                }

            }


            sw.Close();
            Console.ReadKey();
        }
    }
}
