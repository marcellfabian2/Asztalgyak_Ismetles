﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace konyvek
{
    internal class Konyv
    {
        public int Ev { get; set; }
        public int Negyedev { get; set; }
        public string Eredet { get; set; }
        public string Leiras { get; set; }
        public int Pedldanyszam {  get; set; }

        public Konyv(string item)
        {
            string[] tmp = item.Split(';');
            Ev = int.Parse(tmp[0]);
            Negyedev = int.Parse(tmp[1]);
            Eredet = tmp[2];
            Leiras = tmp[3];
            Pedldanyszam = int.Parse(tmp[4]);
        }
    }
}
